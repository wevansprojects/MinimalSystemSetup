#!/bin/bash
#This Script will add a USB drive classified as 'sda' as a permanent
#mounted share and will also mount the drive to /media/fileshare 
#note this only works if the usb is partitioned as sda1 
#and uses ext4 file format

#Add the Fstab entry
id=$(blkid -s UUID -o value /dev/sda1)
someid=$(echo "UUID=$id /media/fileshare ext4 defaults,nofail,noatime 0 0")
echo $someid >> /etc/fstab

#create the folder share
mkdir /media/fileshare

#mount the SD Drive and give ownership to fileshare 
mount -a
chown -R fileshare:fileshare /media/fileshare/

#list the SD Drive File Share
#ls /media/fileshare

