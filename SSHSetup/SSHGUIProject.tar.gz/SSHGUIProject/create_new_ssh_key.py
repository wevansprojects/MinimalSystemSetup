#!/usr/bin/env python3
import subprocess
import os
from datetime import datetime

current_datetime = datetime.now()
date_string = current_datetime.strftime("%Y-%m-%d_%H.%M.%S")


def createconfig():
    whoami_process = subprocess.Popen(["whoami"], stdout=subprocess.PIPE, text=True)
    output, error = whoami_process.communicate()
    sshfolder = "/home/" + output.rstrip() + "/.ssh"
    config_file_process = subprocess.Popen(["touch", "config"])
    config_file_process.wait()
    output, error = config_file_process.communicate()
    move_config_file_process = subprocess.Popen(["mv", "config", sshfolder])
    output, error = move_config_file_process.communicate()
    print("config file created: ")


def checkconfig():
    whoami_process = subprocess.Popen(["whoami"], stdout=subprocess.PIPE, text=True)
    output, error = whoami_process.communicate()
    sshfolder = "/home/" + output.rstrip() + "/.ssh"
    file_path = sshfolder + "/" + "config"

    if os.path.exists(file_path):
        print(f"The file {file_path} exists.")
    else:
        print(f"The file {file_path} does not exist.")
        createconfig()


# To Do - Link Python Script to clientssh-newkey.sh

# use this python script to create a text file with
# the form inputs text from the gui
# the inputted information will be added to the text file
# this file will then be read into the clientssh-newkey.sh
# that shell script will generate the key.


checkconfig()
