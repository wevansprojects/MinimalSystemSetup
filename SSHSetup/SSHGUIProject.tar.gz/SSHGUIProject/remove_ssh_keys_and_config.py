#!/usr/bin/env python3
import subprocess


def remove_ssh_folder():
    whoami_process = subprocess.Popen(["whoami"], stdout=subprocess.PIPE, text=True)
    output, error = whoami_process.communicate()
    sshfolder = "/home/" + output.rstrip() + "/.ssh"
    delete_ssh_folder_process = subprocess.Popen(
        [
            "rm",
            "-rf",
            sshfolder,
        ]
    )
    output, error = delete_ssh_folder_process.communicate()

    recreate_ssh_folder_process = subprocess.Popen(["mkdir", sshfolder])
    output, error = recreate_ssh_folder_process.communicate()

    ssh_folder_permissions_process = subprocess.Popen(["chmod", "700", sshfolder])
    output, error = ssh_folder_permissions_process.communicate()

    print("Task Completed SSH folder removed and recreated: ")
