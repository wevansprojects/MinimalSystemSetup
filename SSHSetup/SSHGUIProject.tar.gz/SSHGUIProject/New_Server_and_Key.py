#!/usr/bin/env python3
import subprocess
import gi

gi.require_version("Gtk", "3.0")

from gi.repository import Gtk


class ServerEntryWindow(Gtk.Window):
    def __init__(self):
        super().__init__(title="New SSH Server Connection")
        self.set_border_width(10)
        self.set_size_request(100, 200)
        grid = Gtk.Grid.new()
        self.action_set_enabledmax_chars = 30
        max_chars = 30
        # Set a uniform width for the labels
        label_width = 100

        # Set Labels
        self.label1 = Gtk.Label("Host:")
        self.label1.set_width_chars(
            label_width // 10
        )  # approximate width in characters
        self.label2 = Gtk.Label("Hostname:")
        self.label2.set_width_chars(label_width // 10)

        self.label3 = Gtk.Label("User:")
        self.label3.set_width_chars(label_width // 10)

        self.label4 = Gtk.Label("Identity File:")
        self.label4.set_width_chars(label_width // 10)

        self.label5 = Gtk.Label("PortNumber:")
        self.label5.set_width_chars(label_width // 10)

        # Set Text Entries
        self.SName = Gtk.Entry()
        self.SName.set_max_length(max_chars)

        self.HName = Gtk.Entry()
        self.HName.set_max_length(max_chars)

        self.User = Gtk.Entry()
        self.User.set_max_length(max_chars)

        self.Identity = Gtk.Entry()
        self.Identity.set_max_length(max_chars)

        self.Port = Gtk.Entry()
        self.Port.set_max_length(max_chars)

        # Attach labels and text entries to grid
        grid.attach(self.label1, 0, 3, 1, 1)
        grid.attach(self.SName, 1, 3, 1, 1)

        grid.attach(self.label2, 0, 4, 1, 1)
        grid.attach(self.HName, 1, 4, 1, 1)

        grid.attach(self.label3, 0, 5, 1, 1)
        grid.attach(self.User, 1, 5, 1, 1)

        grid.attach(self.label4, 0, 6, 1, 1)
        grid.attach(self.Identity, 1, 6, 1, 1)

        grid.attach(self.label5, 0, 7, 1, 1)
        grid.attach(self.Port, 1, 7, 1, 1)

        button1 = Gtk.Button.new_with_mnemonic("Generate")
        grid.attach(button1, 1, 8, 1, 1)

        button1.connect("clicked", self.on_button_click)
        grid.set_row_spacing(5)
        grid.set_column_spacing(5)
        self.add(grid)
        self.show_all()

    def on_button_click(self, button1):
        my_location = subprocess.Popen(["pwd"], stdout=subprocess.PIPE, text=True)
        output, error = my_location.communicate()
        location = output.rstrip()

        whoami_process_ssh = subprocess.Popen(
            ["whoami"], stdout=subprocess.PIPE, text=True
        )
        output, error = whoami_process_ssh.communicate()
        sshfolder = "/home/" + output.rstrip() + "/.ssh"

        iam_process_ssh = subprocess.Popen(
            ["whoami"], stdout=subprocess.PIPE, text=True
        )
        output, error = iam_process_ssh.communicate()
        homefolder ="/home/" + output.rstrip()
    
        new_ssh_folder_process = subprocess.Popen(
            ["mkdir", homefolder + "/ssh_folder" ], stdout=subprocess.PIPE, text=True
            )
        output, error = new_ssh_folder_process.communicate()

        iam_process_ssh = subprocess.Popen(
            ["whoami"], stdout=subprocess.PIPE, text=True
        )
        output, error = iam_process_ssh.communicate()
        ssh_folder ="/home/" + output.rstrip() + "/ssh_folder"

        Host = self.SName.get_text()
        Hostname = self.HName.get_text()
        User = self.User.get_text()
        Identity = self.Identity.get_text()
        Port = self.Port.get_text()
        with open(sshfolder + "/config", "a") as sshconf_file:
            print("\n", file=sshconf_file)
            print(f"# {Host}", file=sshconf_file)
            print(f"Host {Host}", file=sshconf_file)
            print(f"Hostname {Hostname}", file=sshconf_file)
            print(f"User {User}", file=sshconf_file)
            print(f"IdentityFile ~/.ssh/{Identity}", file=sshconf_file)
            print("IdentitiesOnly yes", file=sshconf_file)
            print(f"port {Port}", file=sshconf_file)
            print("ServerAliveInterval 60", file=sshconf_file)
            print("ServerAliveCountMax 120", file=sshconf_file)
            print("\n", file=sshconf_file)
            sshconf_file.close()

        with open(ssh_folder + "/First_SSH_Connect.sh", "w") as firstconnect:
            firstconnect.write(
                f"#!/bin/bash\n"
                f"ssh-keygen -t ecdsa -b 521 -f ~/.ssh/{Identity}\n"
                f"sudo chmod 600 ~/.ssh/{Identity}\n"
                f"sudo chmod 644 ~/.ssh/{Identity}.pub\n"
                f"ssh-copy-id -f -i ~/.ssh/{Identity} -p {Port} {User}@{Hostname} \n"
                f"ssh {Host}\n"
            )
            firstconnect.close()

        with open(
            ssh_folder + "/" + Host + "_Server_SSH_Connect.sh", "w"
        ) as secondconnect:
            secondconnect.write(f"#!/bin/bash\n" f"ssh {Host}\n")
            secondconnect.close()

        self.close()
