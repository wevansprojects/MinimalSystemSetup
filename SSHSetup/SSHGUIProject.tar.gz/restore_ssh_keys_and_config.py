#!/usr/bin/env python3
import subprocess

def restore_ssh_folder():
    whoami_process = subprocess.Popen(["whoami"], stdout=subprocess.PIPE, text=True)
    output, error = whoami_process.communicate()
    homefolder = output.rstrip()
    sshfolder = "/home/" + homefolder + "/.ssh"
    sshrfolder = "/home/" + homefolder + "/Scripts/Python/SSHGUIProject/SSHBackups"
    sshtarfolder = sshfolder + "/sshbackup.tar.gz"

    delete_ssh_folder_process = subprocess.Popen(["rm","-rf",sshfolder,])
    output, error = delete_ssh_folder_process.communicate()

    recreate_ssh_folder_process = subprocess.Popen(["cp", "-r", sshrfolder, sshfolder])
    output, error = recreate_ssh_folder_process.communicate()

    restore_ssh_files_process = subprocess.Popen(["tar", "-xzpvf", sshtarfolder, "-C",sshfolder,])
    output, error = restore_ssh_files_process.communicate()

    ssh_folder_permissions_process = subprocess.Popen(["chmod", "700", sshfolder])
    output, error = ssh_folder_permissions_process.communicate()

    delete_archive_process = subprocess.Popen(["rm" ,sshfolder+"/sshbackup.tar.gz"])
    output, error = delete_archive_process.communicate()

    print("Task Completed SSH folder removed and recreated: ")
