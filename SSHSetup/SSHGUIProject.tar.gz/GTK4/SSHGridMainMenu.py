#!/usr/bin/env python3
import sys
import gi

gi.require_version("Gtk", "4.0")
from gi.repository import Gtk


class AppWindow(Gtk.ApplicationWindow):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

        # Set window properties
        self.set_default_size(260, 300)  # Compact size
        self.set_title("SSH Manager")

        # Create HeaderBar
        header_bar = Gtk.HeaderBar()
        header_bar.set_title_widget(Gtk.Label(label="SSH Manager"))
        self.set_titlebar(header_bar)

        # Apply CSS for font customization
        css_provider = Gtk.CssProvider()
        css_provider.load_from_data(
            b"""
            label, button {
                font-family: Sans;
                font-size: 16px;
            }
            """
        )
        Gtk.StyleContext.add_provider_for_display(
            self.get_display(),
            css_provider,
            Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION,
        )

        # Create a grid layout
        grid = Gtk.Grid()
        grid.set_column_spacing(10)
        grid.set_row_spacing(10)
        grid.set_margin_top(10)
        grid.set_margin_bottom(10)
        grid.set_margin_start(30)
        grid.set_margin_end(10)
        self.set_child(grid)

        # Define button size
        button_width = 100
        button_height = 30

        # Create items with labels and buttons
        items = [
            ("Backup SSH Folder:", self.Backup_SSH_action),
            ("New SSH Server Connection:", self.SSH_New_Key_action),
            ("View SSH Key Details:", self.Show_SSH_Key_Details_action),
            ("Add To SSH Config File:", self.SSH_New_Server_action),
            ("Test SSH Connection:", self.SSH_Connect_action),
            ("Remove SSH Key Entries:", self.SSH_Remove_action),
            ("Restore SSH Key Entries:", self.SSH_Restore_action),
        ]

        # Add items to the grid
        for row, (item_name, action) in enumerate(items):
            # Create the label
            label = Gtk.Label(label=item_name)
            label.set_halign(Gtk.Align.START)

            # Create the button
            button = Gtk.Button(label="Select")
            button.set_size_request(button_width, button_height)
            button.connect("clicked", action)

            # Add label and button to the grid
            grid.attach(label, 0, row, 1, 1)  # Column 0, current row
            grid.attach(button, 1, row, 1, 1)  # Column 1, current row

        # Action methods for buttons

    def Backup_SSH_action(self, button):
        from backup_ssh_gui import SSHArchiveWindow

        ssh_archive_view = SSHArchiveWindow()
        ssh_archive_view.show()

    def SSH_New_Key_action(self, button):
        from New_Server_and_Key import ServerEntryWindow

        ssh_key_view = ServerEntryWindow()
        ssh_key_view.show()

    def Show_SSH_Key_Details_action(self, button):
        from ShowSSHKeyDetails import TreeViewListWindow

        ssh_key_view = TreeViewListWindow()
        ssh_key_view.show()

    def SSH_New_Server_action(self, button):
        from New_SSH_Server_Entry import ServerEntryWindow

        ssh_config_view = ServerEntryWindow()
        ssh_config_view.show()

    def SSH_Connect_action(self, button):
        from Test_Connection import TestConnectionWindow

        ssh_config_view = TestConnectionWindow()
        ssh_config_view.show()

    def SSH_Remove_action(self, button):
        from remove_ssh_keys import SSHRemoveWindow

        ssh_config_view = SSHRemoveWindow()
        ssh_config_view.show()

    def SSH_Restore_action(self, button):
        from restore_ssh_keys import SSHRestoreWindow

        ssh_config_view = SSHRestoreWindow()
        ssh_config_view.show()


class Application(Gtk.Application):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, application_id="ssh.manager.app", **kwargs)
        self.window = None

    def do_activate(self):
        if not self.window:
            self.window = AppWindow(application=self, title="SSH Manager")

        self.window.present()


if __name__ == "__main__":
    app = Application()
    app.run(sys.argv)
