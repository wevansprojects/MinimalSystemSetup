#!/usr/bin/env python3
import sys
import gi

gi.require_version("Gtk", "4.0")
from gi.repository import Gtk, Gio


class AppWindow(Gtk.ApplicationWindow):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.set_margin_top(10)
        self.set_margin_bottom(10)  # Add extra space at the bottom
        self.set_margin_start(10)
        self.set_margin_end(10)

        max_chars = 20
        prompt_str1 = ""
        SNamelbl = Gtk.Label(label=prompt_str1)

        # Set a uniform width for the labels
        label_width = 100

        # Create the first label-entry pair in a horizontal box
        label1 = Gtk.Label(label="Title:")
        label1.set_margin_start(10)  # Move label in a little
        label1.set_width_chars(label_width // 10)  # approximate width in characters
        label1.set_xalign(5)  # Align the label to the left
        SName = Gtk.Entry()
        SName.set_max_length(max_chars)

        hbox1 = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=5)
        hbox1.append(label1)
        hbox1.append(SName)

        # Create the second label-entry pair in a horizontal box
        label2 = Gtk.Label(label="Hostname:")
        label2.set_margin_start(10)  # Move label in a little
        label2.set_width_chars(label_width // 10)  # approximate width in characters
        label2.set_xalign(5)  # Align the label to the left
        HName = Gtk.Entry()
        HName.set_max_length(max_chars)

        hbox2 = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=5)
        hbox2.append(label2)
        hbox2.append(HName)

        # Create the third label-entry pair in a horizontal box
        label3 = Gtk.Label(label="User:")
        label3.set_margin_start(10)  # Move label in a little
        label3.set_width_chars(label_width // 10)  # approximate width in characters
        label3.set_xalign(5)  # Align the label to the left
        UName = Gtk.Entry()
        UName.set_max_length(max_chars)

        hbox3 = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=5)
        hbox3.append(label3)
        hbox3.append(UName)

        # Create the fourth label-entry pair in a horizontal box
        label4 = Gtk.Label(label="IdentityFile:")
        label4.set_margin_start(10)  # Move label in a little
        label4.set_width_chars(label_width // 10)  # approximate width in characters
        label4.set_xalign(5)  # Align the label to the left
        IFile = Gtk.Entry()
        IFile.set_max_length(max_chars)

        hbox4 = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=5)
        hbox4.append(label4)
        hbox4.append(IFile)

        # Create the fifth label-entry pair in a horizontal box
        label5 = Gtk.Label(label="PortNumber:")
        label5.set_margin_start(10)  # Move label in a little
        label5.set_width_chars(label_width // 10)  # approximate width in characters
        label5.set_xalign(5)  # Align the label to the left
        PNo = Gtk.Entry()
        PNo.set_max_length(max_chars)

        hbox5 = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=5)
        hbox5.append(label5)
        hbox5.append(PNo)

        # Main vertical box
        vbox_main = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=20)
        vbox_main.append(SNamelbl)
        vbox_main.append(hbox1)
        vbox_main.append(hbox2)
        vbox_main.append(hbox3)
        vbox_main.append(hbox4)
        vbox_main.append(hbox5)

        # Add a spacer at the bottom
        spacer = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        spacer.set_vexpand(True)  # Ensure the spacer takes available vertical space
        vbox_main.append(spacer)

        self.set_child(vbox_main)


class Application(Gtk.Application):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, application_id="org.example.myapp", **kwargs)
        self.window = None

    def do_activate(self):
        if not self.window:
            self.window = AppWindow(application=self, title="SSH Configuration")
        self.window.show()
        self.window.present()


if __name__ == "__main__":
    app = Application()
    app.run(sys.argv)
