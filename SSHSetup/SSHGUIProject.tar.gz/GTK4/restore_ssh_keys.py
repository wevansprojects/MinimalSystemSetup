#!/usr/bin/env python3
import gi

gi.require_version("Gtk", "4.0")
from gi.repository import Gtk
from restore_ssh_keys_and_config import restore_ssh_folder


class SSHRestoreWindow(Gtk.Window):
    def __init__(self):
        super().__init__(title="Restore")

        # Simulate the border using margins
        self.set_margin_top(40)
        self.set_margin_bottom(40)
        self.set_margin_start(40)
        self.set_margin_end(40)

        # Set the window size to match the original
        self.set_default_size(200, 150)

        # Create a grid layout for precise positioning
        grid = Gtk.Grid()
        grid.set_row_spacing(10)
        grid.set_column_spacing(10)
        grid.set_margin_top(40)  # Simulates space between grid and window edges
        grid.set_margin_bottom(40)
        grid.set_margin_start(40)
        grid.set_margin_end(40)

        # Create the button
        button1 = Gtk.Button(label="Restore Files Now")
        button1.connect("clicked", self.on_button_click)

        # Create the result label
        self.result_label = Gtk.Label(label="")  # Initially empty

        # Add the button and label to the grid
        grid.attach(button1, 0, 0, 1, 1)  # Center the button explicitly
        grid.attach(self.result_label, 0, 1, 1, 1)  # Place the label below the button

        # Set the grid as the main child of the window
        self.set_child(grid)

    def on_button_click(self, button):
        restore_ssh_folder()
        self.result_label.set_text("SSH Key Restore Completed!")


# Run the application
if __name__ == "__main__":
    win = SSHRestoreWindow()
    win.connect("destroy", Gtk.main_quit)
    win.present()
    Gtk.main()
