#!/usr/bin/env python3
import subprocess

def backupfile():
    whoami_process = subprocess.Popen(["whoami"], stdout=subprocess.PIPE, text=True)
    output, error = whoami_process.communicate()
    homefolder = output.rstrip()
    sshfolder = "/home/" + homefolder.rstrip() + "/.ssh"

    delete_ssh_archive_process = subprocess.Popen(
        [
          "rm",
          "SSHBackups/sshbackup.tar.gz",
        ]    
            )
    output, error = delete_ssh_archive_process.communicate()

    gzip_process = subprocess.Popen(
        [
            "tar",
            "-czpvf",
            "sshbackup.tar.gz",
            "-C",
            sshfolder,
            "."
        ]
    )
    gzip_process.wait()
    output, error = gzip_process.communicate()

    merge_file_and_folder_process = subprocess.Popen(
        ["mv", "sshbackup.tar.gz", "SSHBackups/"]
    )
    output, error = merge_file_and_folder_process.communicate()

    listing_archive_process = subprocess.Popen(
        ["tar", "-tf", "SSHBackups/" + "/sshbackup.tar.gz"]
    )
    output, error = listing_archive_process.communicate()
    
    print("Task Completed Check Folder: For Backup Data")
