#!/usr/bin/env python3
import subprocess
import gi

gi.require_version("Gtk", "4.0")
from gi.repository import Gtk


class TestConnectionWindow(Gtk.Window):
    def __init__(self):
        super().__init__(title="Test Connection")
        #        self.set_margin_end(10)
        self.set_default_size(300, 180)  # Set a reasonable window size

        # Create a Box container to center the widgets
        vbox = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=5)
        vbox.set_halign(Gtk.Align.CENTER)  # Center horizontally
        vbox.set_valign(Gtk.Align.CENTER)  # Center vertically

        # Set Labels
        self.label1 = Gtk.Label(label="Server/IP:")
        self.result_label = Gtk.Label(label="")

        # Set Text Entries
        self.Connection = Gtk.Entry()
        self.Connection.set_max_length(30)

        # Create the Submit button
        button1 = Gtk.Button(label="Submit")
        button1.connect("clicked", self.on_button_click)

        # Add widgets to the box
        vbox.append(self.label1)
        vbox.append(self.Connection)
        vbox.append(self.result_label)
        vbox.append(button1)

        # Set the box as the main child of the window
        self.set_child(vbox)

    def on_button_click(self, button1):
        Server = self.Connection.get_text()
        command = ["ssh", "-o", "ConnectTimeout=5", Server, "exit"]
        result = subprocess.call(command)

        # Set the result label text based on the connection result
        if result == 0:
            self.result_label.set_text("Connected!")
        else:
            self.result_label.set_text("Failed!")


# Run the application
if __name__ == "__main__":
    win = TestConnectionWindow()
    win.connect("destroy", Gtk.main_quit)
    win.present()
    Gtk.main()
