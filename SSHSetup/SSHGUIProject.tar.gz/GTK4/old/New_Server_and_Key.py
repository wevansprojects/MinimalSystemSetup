#!/usr/bin/env python3
import subprocess
import gi

gi.require_version("Gtk", "4.0")
from gi.repository import Gtk


class ServerEntryWindow(Gtk.Window):
    def __init__(self):
        super().__init__(title="New Connection")

        # Set the window size slightly larger than the controls
        self.set_default_size(330, 250)  # Slightly wider and taller window

        # Create the main grid container
        grid = Gtk.Grid()
        grid.set_column_homogeneous(False)  # Columns should not stretch
        grid.set_row_homogeneous(False)  # Rows should not stretch
        grid.set_row_spacing(10)
        grid.set_column_spacing(10)

        max_chars = 30
        label_width = 100

        # Set Labels with fixed width and height
        self.label1 = Gtk.Label(label="Host:")
        self.label1.set_size_request(label_width, -1)  # Fixed width, flexible height
        self.label2 = Gtk.Label(label="Hostname:")
        self.label2.set_size_request(label_width, -1)
        self.label3 = Gtk.Label(label="User:")
        self.label3.set_size_request(label_width, -1)
        self.label4 = Gtk.Label(label="Identity File:")
        self.label4.set_size_request(label_width, -1)
        self.label5 = Gtk.Label(label="PortNumber:")
        self.label5.set_size_request(label_width, -1)

        # Set Text Entries with a fixed max length
        self.SName = Gtk.Entry(max_length=max_chars)
        self.SName.set_size_request(200, -1)  # Fixed width, flexible height
        self.HName = Gtk.Entry(max_length=max_chars)
        self.HName.set_size_request(200, -1)
        self.User = Gtk.Entry(max_length=max_chars)
        self.User.set_size_request(200, -1)
        self.Identity = Gtk.Entry(max_length=max_chars)
        self.Identity.set_size_request(200, -1)
        self.Port = Gtk.Entry(max_length=max_chars)
        self.Port.set_size_request(200, -1)

        # Attach labels and text entries to the grid with fixed positions
        grid.attach(self.label1, 0, 0, 1, 1)
        grid.attach(self.SName, 1, 0, 1, 1)

        grid.attach(self.label2, 0, 1, 1, 1)
        grid.attach(self.HName, 1, 1, 1, 1)

        grid.attach(self.label3, 0, 2, 1, 1)
        grid.attach(self.User, 1, 2, 1, 1)

        grid.attach(self.label4, 0, 3, 1, 1)
        grid.attach(self.Identity, 1, 3, 1, 1)

        grid.attach(self.label5, 0, 4, 1, 1)
        grid.attach(self.Port, 1, 4, 1, 1)

        # Create the "Generate" button
        button1 = Gtk.Button(label="Generate")
        button1.connect("clicked", self.on_button_click)
        grid.attach(button1, 1, 5, 1, 1)

        # Set the grid as the window's child widget
        self.set_child(grid)

    def on_button_click(self, button1):
        # Execute commands to generate SSH config and script
        my_location = subprocess.Popen(["pwd"], stdout=subprocess.PIPE, text=True)
        output, error = my_location.communicate()

        whoami_process_ssh = subprocess.Popen(
            ["whoami"], stdout=subprocess.PIPE, text=True
        )
        output, error = whoami_process_ssh.communicate()
        sshfolder = "/home/" + output.rstrip() + "/.ssh"

        iam_process_ssh = subprocess.Popen(
            ["whoami"], stdout=subprocess.PIPE, text=True
        )
        output, error = iam_process_ssh.communicate()
        homefolder = "/home/" + output.rstrip()

        new_ssh_folder_process = subprocess.Popen(
            ["mkdir", homefolder + "/ssh_folder"], stdout=subprocess.PIPE, text=True
        )
        output, error = new_ssh_folder_process.communicate()

        iam_process_ssh = subprocess.Popen(
            ["whoami"], stdout=subprocess.PIPE, text=True
        )
        output, error = iam_process_ssh.communicate()
        ssh_folder = "/home/" + output.rstrip() + "/ssh_folder"

        Host = self.SName.get_text()
        Hostname = self.HName.get_text()
        User = self.User.get_text()
        Identity = self.Identity.get_text()
        Port = self.Port.get_text()

        # Writing to the SSH config file
        with open(sshfolder + "/config", "a") as sshconf_file:
            print("\n", file=sshconf_file)
            print(f"# {Host}", file=sshconf_file)
            print(f"Host {Host}", file=sshconf_file)
            print(f"Hostname {Hostname}", file=sshconf_file)
            print(f"User {User}", file=sshconf_file)
            print(f"IdentityFile ~/.ssh/{Identity}", file=sshconf_file)
            print("IdentitiesOnly yes", file=sshconf_file)
            print(f"port {Port}", file=sshconf_file)
            print("ServerAliveInterval 60", file=sshconf_file)
            print("ServerAliveCountMax 120", file=sshconf_file)
            print("\n", file=sshconf_file)

        # Writing to the First_SSH_Connect script
        with open(ssh_folder + "/First_SSH_Connect.sh", "w") as firstconnect:
            firstconnect.write(
                f"#!/bin/bash\n"
                f"ssh-keygen -t ecdsa -b 521 -f ~/.ssh/{Identity}\n"
                f"sudo chmod 600 ~/.ssh/{Identity}\n"
                f"sudo chmod 644 ~/.ssh/{Identity}.pub\n"
                f"ssh-copy-id -f -i ~/.ssh/{Identity} -p {Port} {User}@{Hostname} \n"
                f"ssh {Host}\n"
            )

        # Writing to the second SSH connect script
        with open(
            ssh_folder + "/" + Host + "_Server_SSH_Connect.sh", "w"
        ) as secondconnect:
            secondconnect.write(f"#!/bin/bash\n" f"ssh {Host}\n")

        self.close()


# Run the application
if __name__ == "__main__":
    win = ServerEntryWindow()
    win.connect("destroy", Gtk.main_quit)
    win.present()
    Gtk.main()
