#!/usr/bin/env python3
import gi

gi.require_version("Gtk", "4.0")
from gi.repository import Gtk
from backup_ssh_keys_and_config import backupfile


class SSHArchiveWindow(Gtk.Window):
    def __init__(self):
        super().__init__(title="SSHKeyBackup")
        self.set_margin_top(40)  # Replaces set_border_width
        self.set_margin_bottom(40)
        self.set_margin_start(40)
        self.set_margin_end(40)

        self.set_default_size(200, 100)  # Adjusted to a reasonable size

        # Create a grid layout
        grid = Gtk.Grid()
        grid.set_row_spacing(5)
        grid.set_column_spacing(5)

        # Create a button
        button1 = Gtk.Button(label="Archive Now")
        button1.connect("clicked", self.on_button_click)

        # Create a label to display the result
        self.result_label = Gtk.Label(label="")

        # Attach widgets to the grid
        grid.attach(button1, 0, 0, 1, 1)
        grid.attach(self.result_label, 0, 1, 1, 1)

        # Set the grid as the main child of the window
        self.set_child(grid)

    def on_button_click(self, button):
        backupfile()
        self.result_label.set_text("Backup Completed!")


# Run the application
if __name__ == "__main__":
    win = SSHArchiveWindow()
    win.connect("destroy", Gtk.main_quit)
    win.present()
    Gtk.main()
