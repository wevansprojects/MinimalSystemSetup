#!/usr/bin/env python3
import gi

gi.require_version("Gtk", "3.0")
from gi.repository import Gtk


class AppWindow(Gtk.ApplicationWindow):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

        self.set_border_width(32)
        self.set_size_request(250, 300)

        # Create the main grid
        main_grid = Gtk.Grid.new()

        # Create an inner frame to hold the main grid with visible border
        inner_frame = Gtk.Frame()
        inner_frame.set_border_width(5)
        inner_frame.set_shadow_type(Gtk.ShadowType.IN)

        # Create the inner grid for buttons and labels
        inner_grid = Gtk.Grid.new()
        inner_frame.add(inner_grid)

        # Create labels and buttons with reduced size
        labels = [
            "Backup SSH folder:",
            "Restore SSH folder:",
            "View SSH Key Details: ",
            "Add SSH Key Details: ",
            "Add Github SSH: ",
            "Test SSH Connection:",
            "Remove SSH Entries:",
        ]

        # Create and attach buttons and labels individually with much smaller buttons
        button1 = Gtk.Button(label="*")
        button1.set_size_request(30, 15)  # Much smaller size: Width: 30px, Height: 15px
        label1 = Gtk.Label.new(labels[0])
        inner_grid.attach(button1, 0, 0, 1, 1)
        inner_grid.attach(label1, 1, 0, 1, 1)

        button2 = Gtk.Button(label="*")
        button2.set_size_request(30, 15)
        label2 = Gtk.Label.new(labels[1])
        inner_grid.attach(button2, 0, 1, 1, 1)
        inner_grid.attach(label2, 1, 1, 1, 1)

        button3 = Gtk.Button(label="*")
        button3.set_size_request(30, 15)
        label3 = Gtk.Label.new(labels[2])
        inner_grid.attach(button3, 0, 2, 1, 1)
        inner_grid.attach(label3, 1, 2, 1, 1)

        button4 = Gtk.Button(label="*")
        button4.set_size_request(30, 15)
        label4 = Gtk.Label.new(labels[3])
        inner_grid.attach(button4, 0, 3, 1, 1)
        inner_grid.attach(label4, 1, 3, 1, 1)

        button5 = Gtk.Button(label="*")
        button5.set_size_request(30, 15)
        label5 = Gtk.Label.new(labels[4])
        inner_grid.attach(button5, 0, 4, 1, 1)
        inner_grid.attach(label5, 1, 4, 1, 1)

        button6 = Gtk.Button(label="*")
        button6.set_size_request(30, 15)
        label6 = Gtk.Label.new(labels[5])
        inner_grid.attach(button6, 0, 5, 1, 1)
        inner_grid.attach(label6, 1, 5, 1, 1)

        # Set spacing for inner grid
        inner_grid.set_row_spacing(5)
        inner_grid.set_column_spacing(5)

        # Add inner frame to the main grid
        main_grid.add(inner_frame)

        # Set spacing for the main grid
        main_grid.set_row_spacing(10)
        main_grid.set_column_spacing(10)

        # Add main grid to the window
        self.add(main_grid)

        button1.connect("clicked", self.SSH_Archive_action)
        button4.connect("clicked", self.SSH_New_Server_action)
        button3.connect("clicked", self.SSH_Show_Keys_action)

    def SSH_Archive_action(self, button1):
        from backup_ssh_gui import SSHArchiveWindow

        ssh_archive_view = SSHArchiveWindow()
        ssh_archive_view.show()

    def SSH_Show_Keys_action(self, button3):
        from ShowSSHKeyDetails import TreeViewListWindow

        ssh_key_view = TreeViewListWindow()
        ssh_key_view.show()

    def SSH_New_Server_action(self, button4):
        from New_SSH_Server_Entry import ServerEntryWindow

        ssh_config_view = ServerEntryWindow()
        ssh_config_view.show()


class Application(Gtk.Application):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, application_id="org.example.myapp", **kwargs)
        self.window = None

    def do_activate(self):
        if not self.window:
            self.window = AppWindow(application=self, title="SSH Key Management")

        self.window.show_all()
        self.window.present()


if __name__ == "__main__":
    app = Application()
    app.run()
