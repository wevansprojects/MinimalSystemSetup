#!/usr/bin/env python3
import subprocess
from datetime import datetime

current_datetime = datetime.now()
date_string = current_datetime.strftime("%Y-%m-%d_%H.%M.%S")


def backupfile():
    whoami_process = subprocess.Popen(["whoami"], stdout=subprocess.PIPE, text=True)
    output, error = whoami_process.communicate()
    sshfolder = "/home/" + output.rstrip() + "/.ssh"
    gzip_process = subprocess.Popen(
        [
            "tar",
            "-cpzf",
            "sshbackup.tar.gz",
            sshfolder,
        ]
    )
    gzip_process.wait()
    output, error = gzip_process.communicate()

    new_backup_folder_process = subprocess.Popen(["mkdir", date_string])
    output, error = new_backup_folder_process.communicate()

    merge_file_and_folder_process = subprocess.Popen(
        ["mv", "sshbackup.tar.gz", date_string]
    )
    output, error = merge_file_and_folder_process.communicate()

    merge_to_backup_folder_process = subprocess.Popen(["mv", date_string, "SSHBackups"])
    output, error = merge_to_backup_folder_process.communicate()

    listing_archive_process = subprocess.Popen(
        ["tar", "-tf", "SSHBackups/" + date_string + "/sshbackup.tar.gz"]
    )
    output, error = listing_archive_process.communicate()
    print("Task Completed Check Folder: " + date_string, "for backup data")
