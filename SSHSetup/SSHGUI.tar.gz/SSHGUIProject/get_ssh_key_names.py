#!/usr/bin/env python3
import re


class Extract_SSH_Keys:
    """Constructor and initializing the class"""

    config_file_data = None
    config_file = None
    collected_data = None
    collected_ips = None

    def get_host_name(self, h):
        hostinfo = re.findall(r"Host (.*)", h)
        return hostinfo

    def get_ssh_key_name(self, sshk):
        nssh = []
        sshkey_name = re.findall(r"IdentityFile (.*)", sshk)
        for rows in sshkey_name:
            # cl = str(rows).strip("~/.ssh/")
            cl = str(rows)
            nssh.append(cl + "  ")
        return nssh

    def get_host_ip(self, hi):
        hostinfo = re.findall(r"Hostname (.*)", hi)
        return hostinfo

    def get_config_data(self, config_file):
        hst = []
        sshinfo = []
        with open(config_file) as file:
            self.config_file_data = list(file.readlines())

            for a in self.config_file_data:
                host = self.get_host_name(a)
                hst.append(host)

            for b in self.config_file_data:
                hostinfo = self.get_ssh_key_name(b)
                sshinfo.append(hostinfo)

        hst = list(filter(None, hst))
        sshinfo = list(filter(None, sshinfo))
        hstn = []
        sshi = []

        for item in hst:
            hstn.append(str(item))
        for item in sshinfo:
            sshi.append(str(item))

        self.collected_data = {hstn[i]: sshi[i] for i in range(len(hstn))}
        return self.collected_data

    def get_ip_data(self, config_file):
        hst = []
        hip = []
        with open(config_file) as file:
            self.config_file_data = list(file.readlines())

            for a in self.config_file_data:
                host = self.get_host_name(a)
                hst.append(host)

            for b in self.config_file_data:
                hostinfo = self.get_host_ip(b)
                hip.append(hostinfo)

        hst = list(filter(None, hst))
        hip = list(filter(None, hip))
        hstn = []
        hips = []

        for item in hst:
            hstn.append(str(item))
        for item in hip:
            hips.append(str(item))

        self.collected_ips = {hstn[i]: hips[i] for i in range(len(hstn))}
        return self.collected_ips
