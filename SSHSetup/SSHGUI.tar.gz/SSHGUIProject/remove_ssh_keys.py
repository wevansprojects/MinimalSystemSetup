#!/usr/bin/env python3
import gi

gi.require_version("Gtk", "3.0")
from gi.repository import Gtk
from remove_ssh_keys_and_config import remove_ssh_folder


class SSHRemoveWindow(Gtk.Window):
    def __init__(self):
        super().__init__(title="Remove SSH Keys")
        self.set_border_width(10)
        self.set_size_request(100, 200)
        grid = Gtk.Grid.new()

        button1 = Gtk.Button.new_with_mnemonic("Remove Now")
        self.result_label = Gtk.Label()
        self.result_label.set_label("")
        grid.attach(button1, 1, 2, 1, 1)
        grid.attach(self.result_label, 1, 3, 1, 1)
        button1.connect("clicked", self.on_button_click)
        grid.set_row_spacing(5)
        grid.set_column_spacing(5)
        self.add(grid)
        self.show_all()

    def on_button_click(self, button1):
        remove_ssh_folder()
        self.result_label.set_text("Backup Completed!")
