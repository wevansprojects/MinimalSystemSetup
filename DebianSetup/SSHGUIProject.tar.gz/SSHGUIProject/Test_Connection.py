#!/usr/bin/env python3
import subprocess
import gi

gi.require_version("Gtk", "3.0")

from gi.repository import Gtk


class TestConnectionWindow(Gtk.Window):
    def __init__(self):
        super().__init__(title="Test SSH Server Connection")
        self.set_border_width(10)
        self.set_size_request(100, 200)
        grid = Gtk.Grid.new()
        self.action_set_enabledmax_chars = 30
        max_chars = 30
        # Set a uniform width for the labels
        label_width = 100

        # Set Labels
        self.label1 = Gtk.Label("Connection:")
        self.label1.set_width_chars(
            label_width // 10
        )  # approximate width in characters

        self.result_label = Gtk.Label("")
        self.result_label.set_width_chars(label_width // 10)

        # Set Text Entries
        self.Connection = Gtk.Entry()
        self.Connection.set_max_length(max_chars)

        # Attach labels and text entries to grid
        grid.attach(self.label1, 0, 3, 1, 1)
        grid.attach(self.Connection, 1, 3, 1, 1)
        grid.attach(self.result_label, 1, 4, 1, 1)
        button1 = Gtk.Button.new_with_mnemonic("Submit")
        grid.attach(button1, 1, 5, 1, 1)

        button1.connect("clicked", self.on_button_click)
        grid.set_row_spacing(5)
        grid.set_column_spacing(5)
        self.add(grid)
        self.show_all()

    def on_button_click(self, button1):
        Server = self.Connection.get_text()
        command = ["ssh", "-o", "ConnectTimeout=5", Server, "exit"]
        subprocess.call(command)
        if subprocess.call(command) == 0:
            self.result_label.set_text("Connected!")
        else:
            self.result_label.set_text("Failed!")
