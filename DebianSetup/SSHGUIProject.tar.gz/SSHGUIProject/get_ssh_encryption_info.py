#!/usr/bin/env python3
from sshkeys import Key
import re


class Export_Encryption_Info:
    """Constructor and initializing the class"""

    config_file_data = None
    config_file = None
    collected_data = None

    def get_host_name(self, h):
        hostinfo = re.findall(r"Host (.*)", h)
        return hostinfo

    def get_ssh_key_name(self, sshk):
        nssh = []
        sshkey_name = re.findall(r"IdentityFile (.*)", sshk)
        for rows in sshkey_name:
            cl = str(rows).replace("~/.ssh/", "")
            nssh.append(cl)
        return nssh

    def get_config_data(self, config_file):
        hst = []
        sshinfo = []
        with open(config_file) as file:
            self.config_file_data = list(file.readlines())

            for a in self.config_file_data:
                host = self.get_host_name(a)
                hst.append(host)

            for b in self.config_file_data:
                hostinfo = self.get_ssh_key_name(b)
                sshinfo.append(hostinfo)

        hst = list(filter(None, hst))
        sshinfo = list(filter(None, sshinfo))
        hstn = []
        sshi = []

        for item in hst:
            hstn.append(str(item))
        for item in sshinfo:
            sshi.append(str(item))

        self.collected_data = {hstn[i]: sshi[i] for i in range(len(hstn))}
        return self.collected_data


def main():
    cf = "/home/debuser/.ssh/config"
    sshkeyinfo = []
    lookupkey = []
    getmysshkeys = Export_Encryption_Info().get_config_data(cf)

    for rows in getmysshkeys.values():
        cl = str(rows).strip("'[]'")
        sshkeyinfo.append(cl)

    for rows in sshkeyinfo:
        nw = "/home/debuser/.ssh/" + rows + ".pub"
        lookupkey.append(nw)

    print(lookupkey)

    for key in lookupkey:
        k = Key.from_pubkey_file(key)
        print(k.type)

    for key in lookupkey:
        k = Key.from_pubkey_file(key)


if __name__ == "__main__":
    main()
