#!/usr/bin/env python3
import sys

from gi.repository import Pango

import gi

gi.require_version("Gtk", "3.0")
gi.require_version("Pango", "1.0")
from gi.repository import Gtk


class AppWindow(Gtk.ApplicationWindow):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

        font_desc = Pango.FontDescription("Sans 12")  # Font name and size

        self.set_border_width(40)
        self.set_size_request(250, 100)
        grid = Gtk.Grid.new()
        label1 = Gtk.Label.new("Backup SSH folder: ")
        label1.modify_font(font_desc)
        label2 = Gtk.Label.new("New SSH Server Connection: ")
        label2.modify_font(font_desc)
        label3 = Gtk.Label.new("View SSH Key Details: ")
        label3.modify_font(font_desc)
        label4 = Gtk.Label.new("Add To SSH Config File: ")
        label4.modify_font(font_desc)
        label5 = Gtk.Label.new("Test SSH Connection: ")
        label5.modify_font(font_desc)
        label6 = Gtk.Label.new("Remove SSH Entries: ")
        label6.modify_font(font_desc)

        button1 = Gtk.Button.new_with_mnemonic("Select")
        button2 = Gtk.Button.new_with_mnemonic("Select")
        button3 = Gtk.Button.new_with_mnemonic("Select")
        button4 = Gtk.Button.new_with_mnemonic("Select")
        button5 = Gtk.Button.new_with_mnemonic("Select")
        button6 = Gtk.Button.new_with_mnemonic("Select")

        button1.connect("clicked", self.SSH_Archive_action)
        button2.connect("clicked", self.SSH_New_Key_action)
        button4.connect("clicked", self.SSH_New_Server_action)
        button3.connect("clicked", self.SSH_Show_Keys_action)
        button5.connect("clicked", self.SSH_Connect_action)
        button6.connect("clicked", self.SSH_Remove_action)

        grid.attach(label1, 0, 1, 1, 1)
        grid.attach(label2, 0, 2, 1, 1)
        grid.attach(label3, 0, 3, 1, 1)
        grid.attach(label4, 0, 4, 1, 1)
        grid.attach(label5, 0, 5, 1, 1)
        grid.attach(label6, 0, 6, 1, 1)

        grid.attach(button1, 1, 1, 1, 1)
        grid.attach(button2, 1, 2, 1, 1)
        grid.attach(button3, 1, 3, 1, 1)
        grid.attach(button4, 1, 4, 1, 1)
        grid.attach(button5, 1, 5, 1, 1)
        grid.attach(button6, 1, 6, 1, 1)

        grid.set_row_spacing(5)
        grid.set_column_spacing(5)
        self.add(grid)

    def SSH_Archive_action(self, button1):
        from backup_ssh_gui import SSHArchiveWindow

        ssh_archive_view = SSHArchiveWindow()
        ssh_archive_view.show()

    def SSH_New_Key_action(self, button2):
        from New_Server_and_Key import ServerEntryWindow

        ssh_key_view = ServerEntryWindow()
        ssh_key_view.show()

    def SSH_Show_Keys_action(self, button3):
        from ShowSSHKeyDetails import TreeViewListWindow

        ssh_key_view = TreeViewListWindow()
        ssh_key_view.show()

    def SSH_New_Server_action(self, button4):
        from New_SSH_Server_Entry import ServerEntryWindow

        ssh_config_view = ServerEntryWindow()
        ssh_config_view.show()

    def SSH_Connect_action(self, button5):
        from Test_Connection import TestConnectionWindow

        ssh_config_view = TestConnectionWindow()
        ssh_config_view.show()

    def SSH_Remove_action(self, button6):
        from remove_ssh_keys import SSHRemoveWindow

        ssh_config_view = SSHRemoveWindow()
        ssh_config_view.show()


class Application(Gtk.Application):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, application_id="org.example.myapp", **kwargs)
        self.window = None

    def do_activate(self):
        if not self.window:
            self.window = AppWindow(application=self, title="SSH Manager")

        self.window.show_all()
        self.window.present()


if __name__ == "__main__":
    app = Application()
    app.run(sys.argv)
