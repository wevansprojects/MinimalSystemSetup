#!/usr/bin/env python3
import gi
from gi.repository import Pango

from get_ssh_key_names import Extract_SSH_Keys
from get_ssh_encryption_info import Export_Encryption_Info
from sshkeys import Key


gi.require_version("Gtk", "3.0")
gi.require_version("Pango", "1.0")

from gi.repository import Gtk
from gi.repository import Pango


Server = []
KeyLocation = []
kys = []
ktype = []
cf = "/home/debuser/.ssh/config"
sshkeyinfo = []
lookupkey = []
getmysshkeys = Export_Encryption_Info().get_config_data(cf)
ssh_server_list = Extract_SSH_Keys().get_config_data(cf)
ipinfo_list = Extract_SSH_Keys().get_ip_data(cf)

for rows in ssh_server_list.values():
    sn = str(rows).strip("'[]'")
    Server.append(sn)

for r in ssh_server_list.keys():
    ks = str(r).strip("'[]'")
    kys.append(ks)

for ro in ipinfo_list.values():
    ips = str(ro).strip("'[]'")
    KeyLocation.append(ips)

for rows in getmysshkeys.values():
    cl = str(rows).strip("'[]'")
    sshkeyinfo.append(cl)

for rows in sshkeyinfo:
    nw = "/home/debuser/.ssh/" + rows + ".pub"
    lookupkey.append(nw)

for key in lookupkey:
    k = Key.from_pubkey_file(key)
    ktype.append(k.type)


class TreeViewListWindow(Gtk.Window):
    def __init__(self):
        super().__init__(title="SSH Key Information")
        self.set_border_width(10)

        # Setting up the grid in which the elements are to be positioned
        self.grid = Gtk.Grid()
        self.grid.set_column_homogeneous(True)
        self.grid.set_row_homogeneous(True)
        self.add(self.grid)

        # Creating the ListStore model
        self.liststore = Gtk.ListStore(str, str, str, str)
        for server, keys, key_location, kt in zip(Server, kys, KeyLocation, ktype):
            self.liststore.append([keys, server, key_location, kt])

        # Creating the treeview and adding the columns
        self.treeview = Gtk.TreeView(model=self.liststore)

        for i, column_title in enumerate(
            ["Server Name", "Key Name", "IP/URL", "Encryption Type"]
        ):
            renderer = Gtk.CellRendererText()
            column = Gtk.TreeViewColumn(column_title, renderer, text=i)
            self.treeview.append_column(column)
            font_desc = Pango.FontDescription("Sans 11")  # font name and size
            renderer.set_property(
                "font-desc", font_desc
            )  # Apply font description to the cell renderer

        # Setting up the layout, putting the treeview in a scroll window
        self.scrollable_treelist = Gtk.ScrolledWindow()
        self.scrollable_treelist.set_vexpand(True)
        self.scrollable_treelist.set_size_request(
            500, 240
        )  # Set the height to show 5 rows initially
        self.grid.attach(self.scrollable_treelist, 0, 0, 2, 10)
        self.scrollable_treelist.add(self.treeview)

        self.show_all()


# win = TreeViewListWindow()
# win.connect("destroy", Gtk.main_quit)
# win.show_all()
# Gtk.main()
